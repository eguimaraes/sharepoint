﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data.SqlClient;




namespace imdb
{
    public class Service1 : IService1
    {


        public filme GetFilme(int id) {
        
        return GetFilmes(GetFiltro("id",id.ToString()))[0];
        
        }




        public string GetFiltro(string coluna, string valor) {

            return ((coluna!=null)&&(valor!=null))?(string.Format("where {0}='{1}'",coluna,valor)):"";

        
        }



        public List<filme> GetFilmes(string coluna, string valor) {


            return GetFilmes(GetFiltro(coluna,valor));
        
        
        
        }


        
        public List<filme> GetFilmes(string filtro) {

            List<filme> filmes = new List<filme>();
            
            string conexaoStr="Data Source=london;Initial Catalog=filmes;Integrated Security=True";

            SqlConnection conexao = new SqlConnection(conexaoStr);

            string QueryStr = "select * from catalogo "+filtro;

            SqlCommand Comand = new SqlCommand(QueryStr);

            conexao.Open();

            Comand.Connection = conexao;

            SqlDataReader Dados = Comand.ExecuteReader();

            while (Dados.Read()) {

                filme filme = new filme();

                filme.id = Convert.ToInt32(Dados["id"]);
                filme.diretor = Dados["diretor"].ToString();
                filme.titulo = Dados["titulo"].ToString();
                filme.ano = Dados["ano"].ToString();

                filmes.Add(filme);

            }

            return filmes;

        }

       


    }
}
