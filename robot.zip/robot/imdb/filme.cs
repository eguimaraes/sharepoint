﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace imdb
{
   
    public class filme
    {

        public int id;
        public string titulo="";
        public string diretor="";
        public string ano="";


       public filme() {  }



        
         

    }
}