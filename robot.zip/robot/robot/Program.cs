﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;

namespace robot
{
    class Program
    {

       public static string URL = "http://dev.contoso.com";
       public static string ListName = "Compras";


       static void Main(string[] args)
       {
           try
           {
               //ListarItens(URL,ListName);           
               //CriarItens(1000);

               Apagar("Teste");
               Console.WriteLine("Executado com Sucesso");
               Console.ReadLine();
           }
           catch (Exception e) {

               Console.WriteLine("Falha"+e.StackTrace);
               Console.ReadLine();
           
           
           }


       }

       private static void Atualizar(string ValorAtual, string NovoValor)
       {

           using (SPSite site = new SPSite(URL))
           {

               using (SPWeb web = site.RootWeb)
               {

                   SPList catalogo = web.Lists[ListName];

                   SPListItemCollection items = catalogo.GetItems(GetQuery(ValorAtual));


                   foreach(SPListItem item in items){

                       item["Title"] = NovoValor;
                   //item["Ano"] = "Teste";
                   //item["Diretor"] = "Teste";
                   item.Update();

                       }

               }

           }
            


           
       }


       private static void Apagar(string ValorAtual)
       {

           using (SPSite site = new SPSite(URL))
           {

               using (SPWeb web = site.RootWeb)
               {
                   SPList catalogo = web.Lists[ListName];

                   SPListItemCollection items = catalogo.GetItems(GetQuery(ValorAtual));
                   
                   while(items.Count>0) {

                       items = catalogo.GetItems(GetQuery(ValorAtual));

                       Console.WriteLine("Apagando item {0}",  items[0].ID);
                       
                       items[0].Delete();
                   }

               }

           }




       }


        public static SPQuery GetQuery(string busca) {

            SPQuery Query = new SPQuery();

            Query.Query="<Where><Contains><FieldRef Name=\"Title\" /><Value Type=\"Text\">"+busca+"</Value></Contains></Where>";

            return Query;
        
        }

        private static void CriarItens(int p)
        {
            for (int i = 0; i < p; i++)
            {
               CriarItem(URL, ListName);

            }
        }

        private static void CriarItem(string URL, string ListTitle)
        {
            using (SPSite site = new SPSite(URL))
            {

                using (SPWeb web = site.RootWeb)
                {

                    SPList catalogo = web.Lists[ListTitle];

                    SPListItem item = catalogo.Items.Add();

                    item["Title"] = "Teste";
                    item["Ano"] = "Teste";
                    item["Diretor"] = "Teste";
                    item.Update();                    

                }

            }
            

        }

     

        private static void ListarItens(string URL,string ListTitle)
        {
            using (SPSite site = new SPSite(URL))
            {

                using (SPWeb web = site.RootWeb)
                {

                    SPList catalogo = web.Lists[ListTitle];

                    foreach (SPListItem item in catalogo.Items)
                    {

                        Console.WriteLine(item["Title"].ToString());


                    }

                }

            }

            Console.ReadLine();
        }
    }
}
